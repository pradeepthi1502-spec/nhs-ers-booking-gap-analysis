# Source Code

This folder contains reusable Python scripts for cleaning, transforming and exporting analysis-ready datasets.

## Scripts

| File | Purpose |
|---|---|
| build_ers_tableau_fact.py | Builds the final e-RS Tableau fact table |
| clean_rtt_monthly.py | Cleans Referral to Treatment monthly data |
| clean_dm01_diagnostics.py | Cleans diagnostic waiting-time data |
| clean_cwt_cancer_waiting_times.py | Cleans cancer waiting-times data |
| create_date_dimension_and_validate.py | Creates date dimension and validation checks |
| build_rtt_dumbbell_comparison.py | Creates RTT comparison dataset for Tableau |

## Run Example

```bash
python src/build_ers_tableau_fact.py
```

## Why This Folder Exists

Notebooks show the step-by-step analytical workflow. The `src` folder shows the cleaned, reusable code that can be run directly.
