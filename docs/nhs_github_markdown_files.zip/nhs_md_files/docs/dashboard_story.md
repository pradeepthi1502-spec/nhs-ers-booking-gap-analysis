# Tableau Dashboard Story

## Final Story Framing

The project is framed around the hidden gap before the waiting list. The core idea is that referral demand entering the NHS e-Referral Service does not always convert into booked appointments. This creates an upstream access-pressure signal that can be analysed by time, specialty, region and bottleneck type.

The dashboard avoids overclaiming. It does not state that e-RS Appointment Slot Issues caused RTT deterioration or diagnostic waiting-time pressure. Instead, downstream indicators are used as wider access-system context.

## Page 1: The hidden gap before the waiting list

### Main Message

The NHS referral system is absorbing less demand than it receives. Monthly referrals minus bookings show where demand entered e-RS faster than appointments were booked.

### Main Chart

National e-RS Demand Conversion Gap

### Supporting Message

The issue is not only referral volume. The key pressure is the gap between demand entering e-RS and the share converted into booked appointments.

### Suggested Layout

Use one dominant national trend chart. Keep the page simple and high impact.

## Page 2: Where the booking gap concentrates

### Main Message

The booking gap is not evenly spread. A small number of local service combinations and specialties carry a disproportionate share of unabsorbed demand.

### Charts

1. Concentration of the e-RS Demand Gap
2. Specialties Driving the e-RS Demand-to-Booking Gap
3. Appointment Slot Issue Persistence by Specialty

### Suggested Layout

Left side:

- Concentration curve as the main chart

Right side:

- Specialty demand gap bar chart
- ASI persistence by specialty

## Page 3: Where intervention should be escalated first

### Main Message

The highest-priority areas are not just busy. They combine weak booking absorption, high appointment-slot pressure and large referral volume. Different bottleneck types need different operational responses.

### Charts

1. Capacity Escalation Matrix
2. Bottleneck Archetype Fingerprint
3. Regional Bottleneck Hotspot Map or Regional Composition of Bottleneck Archetypes
4. RTT or diagnostic context chart

### Suggested Layout

Top left:

- Capacity Escalation Matrix

Top right:

- Bottleneck Archetype Fingerprint

Bottom left:

- Regional hotspot map or regional archetype composition

Bottom right:

- One downstream context chart

## Charts to Keep in Main Dashboard

- National e-RS Demand Conversion Gap
- Concentration of e-RS Demand Gap
- Specialties Driving Demand Gap
- ASI Persistence by Specialty
- Capacity Escalation Matrix
- Bottleneck Archetype Fingerprint
- Regional Hotspot Map or Regional Archetype Composition
- One downstream context chart

## Charts to Keep as Appendix or Supporting Analysis

- Archetype Membership Detail
- Archetype Separation Boxplot
- ASI Shock Recovery Curve
- Regional Spread of Booking Absorption
- Both RTT and Diagnostic charts together, unless there is enough space

## Final Caveat for Dashboard

This analysis counts referral events, not unique patients. Appointment Slot Issues show where no appointment slot was available at booking or search time. They do not directly prove clinical harm, deliberate capacity diversion or individual waiting outcomes.
