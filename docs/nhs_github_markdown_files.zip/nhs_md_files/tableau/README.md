# Tableau Dashboard

This folder stores the Tableau workbook and dashboard screenshots.

## Recommended Structure

```text
tableau/
├── workbook.twbx
└── screenshots/
    ├── dashboard_1_overview.png
    ├── story_page_1_demand_gap.png
    ├── story_page_2_concentration.png
    └── story_page_3_intervention.png
```

## Dashboard Story Pages

1. The hidden gap before the waiting list
2. Where the booking gap concentrates
3. Where intervention should be escalated first

## Screenshot Guidance

Screenshots should be cropped to show only the dashboard area. Avoid including browser tabs, Tableau Public side recommendations or editing controls.

## Tableau Public Link

Add Tableau Public URL here:

```text
PLACEHOLDER: Add Tableau Public dashboard URL
```
