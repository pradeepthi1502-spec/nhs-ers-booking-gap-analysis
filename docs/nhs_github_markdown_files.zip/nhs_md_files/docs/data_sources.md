# Data Sources

This project uses public NHS and ONS data sources to analyse referral demand, bookings, Appointment Slot Issues, geography, diagnostic waiting times and Referral to Treatment context.

## 1. NHS e-Referral Service Open Data

Used for referrals, bookings, Appointment Slot Issues, clinic type, specialty and Sub-ICB / CCG level analysis.

Source:

```text
https://digital.nhs.uk/data-and-information/publications/statistical/mi-nhs-e-referral-service-open-data/current/data-tables
```

Dashboard context:

```text
https://digital.nhs.uk/dashboards/ers-open-data
```

## 2. Sub-ICB to ICB to NHS England Region Lookup

Used to enrich the e-RS dataset with Sub-ICB, ICB and NHS England region mapping.

Source:

```text
https://geoportal.statistics.gov.uk/datasets/sub-icb-locations-to-integrated-care-boards-to-nhser-april-2024-lookup-in-en/about
```

Backup source:

```text
https://www.data.gov.uk/dataset/0b442793-eb65-4f6e-9e22-d8562ef7967a/sub-icb-locations-to-integrated-care-boards-to-nhser-april-2024-lookup-in-en
```

## 3. Monthly Diagnostic Waiting Times and Activity

Used as downstream healthcare access context, especially for diagnostic waits over six weeks.

NHS England source:

```text
https://www.england.nhs.uk/statistics/statistical-work-areas/diagnostics-waiting-times-and-activity/monthly-diagnostics-waiting-times-and-activity/
```

NHS Digital alternative source:

```text
https://digital.nhs.uk/data-and-information/publications/statistical/nhse-diagnostics-waiting-times-and-activity-data
```

## 4. Referral to Treatment Waiting Times

Used as downstream access-pressure context and for comparison of treatment function performance.

Main RTT source:

```text
https://www.england.nhs.uk/statistics/statistical-work-areas/rtt-waiting-times/
```

2019/20 RTT data:

```text
https://www.england.nhs.uk/statistics/statistical-work-areas/rtt-waiting-times/rtt-data-2019-20/
```

2024/25 RTT data:

```text
https://www.england.nhs.uk/statistics/statistical-work-areas/rtt-waiting-times/rtt-data-2024-25/
```

## Data Storage Decision

Raw NHS files are not stored in this repository because the source data contains many files and can be large. The repository stores processed, analysis-ready datasets to make the project reproducible without making the repository unnecessarily heavy.

Recommended storage approach:

```text
data/raw/        source files not uploaded, source links provided here
data/interim/    temporary cleaned files not uploaded
data/processed/  final analysis-ready datasets uploaded
```
