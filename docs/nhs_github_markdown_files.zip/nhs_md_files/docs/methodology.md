# Methodology

## 1. Objective

The objective of this project is to identify where NHS e-Referral Service demand is not fully converting into booked appointments. The analysis focuses on referral demand, booking absorption, Appointment Slot Issues, regional variation, specialty pressure and bottleneck archetypes.

## 2. Data Ingestion

The project uses NHS e-Referral Service data covering:

- Referrals
- Bookings
- Appointment Slot Issues
- Clinic type
- Specialty
- Sub-ICB or CCG geography

Additional datasets were used for geography enrichment and downstream healthcare access context.

## 3. Data Cleaning

The cleaning process included:

- Loading multiple source files using Python.
- Standardising column names.
- Converting week-ending fields into valid date fields.
- Cleaning specialty and clinic type fields.
- Aligning referral, booking and ASI records at the correct granularity.
- Removing duplicate records where required.
- Handling missing geography matches.

## 4. Data Merging

The e-RS tables were merged to create a single Tableau-ready fact table. The key merge dimensions were:

- Week ending date
- Specialty
- Clinic type
- Sub-ICB or CCG code
- Sub-ICB or CCG name

The final output was enriched with geography fields, including NHS England region and coordinates for mapping.

## 5. Metric Engineering

The main metrics created were:

- Booking absorption rate
- Demand-to-booking gap
- Positive demand gap
- Appointment Slot Issue rate per 10,000 referrals
- Regional pressure indicators
- Specialty pressure indicators
- Bottleneck archetypes

## 6. Bottleneck Classification

Bottleneck groups were created to make the analysis more operationally useful. The classification logic considered both booking absorption and appointment-slot pressure.

Example interpretation groups:

- Booking bottlenecks
- High pressure, still converting
- Low conversion watchlist
- Lower pressure, coping better

These groups help avoid treating all access-pressure areas as the same type of problem.

## 7. Tableau Dashboard Development

The dashboard was designed as a three-page Tableau story:

1. The hidden gap before the waiting list
2. Where the booking gap concentrates
3. Where intervention should be escalated first

The dashboard prioritises decision-making over chart volume. Some technical charts were kept as supporting analysis rather than forced into the main story.

## 8. Validation Checks

Validation included:

- Checking total referrals, bookings and ASIs after merging.
- Checking date ranges and monthly aggregation.
- Checking missing geography rates.
- Comparing specialty totals before and after aggregation.
- Reviewing Tableau outputs against Python summary tables.

## 9. Interpretation Approach

Appointment Slot Issues are treated as an upstream access-pressure signal. The analysis does not claim that ASIs directly caused RTT deterioration or diagnostic waits. Downstream RTT and diagnostic indicators are used only as wider context.
