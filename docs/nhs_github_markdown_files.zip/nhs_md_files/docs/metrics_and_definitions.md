# Metrics and Definitions

## Booking Absorption Rate

```text
Booking Absorption Rate = Bookings / Referrals
```

This measures the proportion of referral demand that converted into booked appointments. A lower rate suggests that referral demand is not being absorbed effectively into bookings.

## Demand-to-Booking Gap

```text
Demand-to-Booking Gap = Referrals - Bookings
```

This measures the difference between referral demand and booked appointments. A positive gap indicates that referrals exceeded bookings.

## Positive Demand Gap

```text
Positive Demand Gap = max(Referrals - Bookings, 0)
```

This focuses only on cases where referral demand exceeded bookings. It avoids offsetting high-pressure services with services where bookings exceeded referrals.

## Appointment Slot Issue Rate per 10,000 Referrals

```text
ASI Rate per 10,000 Referrals = (Appointment Slot Issues / Referrals) × 10,000
```

This standardises no-slot pressure so that specialties or regions with different referral volumes can be compared more fairly.

## Routine ASI Rate per 10,000 Referrals

```text
Routine ASI Rate per 10,000 Referrals = (Routine ASIs / Routine Referrals) × 10,000
```

This measures appointment-slot pressure for routine or non-urgent suspected cancer pathways.

## 2WW ASI Rate per 10,000 Referrals

```text
2WW ASI Rate per 10,000 Referrals = (2WW ASIs / 2WW Referrals) × 10,000
```

This measures appointment-slot pressure for urgent suspected cancer pathways.

## Routine-to-2WW ASI Ratio

```text
Routine-to-2WW ASI Ratio = Routine ASI Rate / 2WW ASI Rate
```

This compares routine no-slot pressure with urgent suspected cancer no-slot pressure.

## Bottleneck Archetype

A bottleneck archetype is a classification used to group local service combinations by operational pressure. It considers both booking absorption and ASI pressure.

Example categories:

| Archetype | Interpretation |
|---|---|
| Booking bottlenecks | Low booking absorption and high slot pressure |
| High pressure, still converting | High slot pressure but bookings are still converting relatively well |
| Low conversion watchlist | Low booking absorption but lower slot pressure |
| Lower pressure, coping better | Higher absorption and lower slot pressure |

## Important Interpretation Note

These metrics describe referral events and booking behaviour. They do not measure unique patients and should not be interpreted as direct clinical outcomes.
