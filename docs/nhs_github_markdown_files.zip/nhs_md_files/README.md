# NHS e-RS Booking Gap Analysis

## Project Overview

This project analyses NHS e-Referral Service open data to identify where referral demand is not fully converting into booked appointments. The analysis focuses on booking absorption, appointment-slot pressure, demand-to-booking gaps, regional bottlenecks, specialty-level pressure and bottleneck archetypes.

The project combines Python-based data preparation with Tableau dashboard storytelling to show a hidden access-pressure signal before patients appear in downstream waiting-list measures.

## Business Question

Where is NHS referral demand not converting into booked appointments, and which regions, specialties and bottleneck types should be prioritised for intervention?

## Why This Matters

Referral demand alone does not explain access pressure. A service can receive high referral volume but still cope if bookings absorb demand effectively. The more important operational question is where demand enters the e-Referral Service but does not convert into booked appointments at the same rate.

This project treats Appointment Slot Issues as an upstream access-pressure signal and uses them alongside referrals, bookings and geography data to identify where bottlenecks concentrate.

## Key Insights

- Referral demand is not evenly absorbed into bookings across time, region and specialty.
- Demand-to-booking gaps are concentrated in specific local service combinations rather than evenly spread across the NHS.
- Some specialties repeatedly appear as high contributors to unabsorbed referral demand.
- Regional averages can hide local access risk, especially where low booking absorption combines with high appointment-slot pressure.
- Different bottleneck archetypes require different operational responses rather than one generic capacity fix.

## Dashboard Story

The Tableau story is organised into three pages:

### Page 1: The hidden gap before the waiting list

Shows the national e-RS demand conversion gap and booking absorption trend.

### Page 2: Where the booking gap concentrates

Shows how unabsorbed demand concentrates across local service combinations and specialties.

### Page 3: Where intervention should be escalated first

Shows priority areas using capacity escalation, bottleneck archetypes and regional hotspot patterns.

## Tools Used

- Python
- pandas
- NumPy
- Jupyter Notebook
- Tableau Public
- NHS Open Data
- ONS Geography Lookup

## Repository Structure

```text
nhs-ers-booking-gap-analysis/
├── README.md
├── requirements.txt
├── .gitignore
├── LICENSE
├── data/
│   ├── raw/
│   ├── interim/
│   └── processed/
├── notebooks/
├── src/
├── tableau/
└── docs/
```

## Data Pipeline

1. Loaded NHS e-Referral Service referrals, bookings and Appointment Slot Issue datasets.
2. Standardised column names and date fields.
3. Combined multiple source files into analysis-ready tables.
4. Added Sub-ICB, ICB and NHS England region geography.
5. Engineered metrics including booking absorption rate, demand-to-booking gap and ASI rate per 10,000 referrals.
6. Created specialty, regional and bottleneck archetype summaries.
7. Built Tableau dashboard pages for insight communication.

## Core Metrics

| Metric | Definition | Purpose |
|---|---|---|
| Booking Absorption Rate | Bookings / Referrals | Measures how much referral demand converts into booked appointments |
| Demand-to-Booking Gap | Referrals - Bookings | Identifies unabsorbed referral demand |
| Positive Demand Gap | Max(Referrals - Bookings, 0) | Focuses only on demand that exceeds bookings |
| ASI Rate per 10,000 Referrals | Appointment Slot Issues / Referrals × 10,000 | Standardises no-slot pressure across services |
| Bottleneck Archetype | Classification based on absorption and slot pressure | Supports operational prioritisation |

## Dashboard Preview

Add exported Tableau screenshots inside `tableau/screenshots/`, then uncomment or update the image paths below.

```markdown
![Overview Dashboard](tableau/screenshots/dashboard_1_overview.png)
![Story Page 1](tableau/screenshots/story_page_1_demand_gap.png)
![Story Page 2](tableau/screenshots/story_page_2_concentration.png)
![Story Page 3](tableau/screenshots/story_page_3_intervention.png)
```

## Tableau Public Link

Add Tableau Public link here:

```text
PLACEHOLDER: Add Tableau Public dashboard URL
```

## How to Reproduce

Install dependencies:

```bash
pip install -r requirements.txt
```

Run the Python pipeline:

```bash
python src/build_ers_tableau_fact.py
```

Processed outputs should be saved inside:

```text
data/processed/
```

## Data Sources

The project uses publicly available NHS and ONS data sources. Full source links are listed in:

```text
docs/data_sources.md
```

Raw NHS files are not stored in this repository due to volume and file size. Processed analysis-ready datasets are included for reproducibility.

## Limitations

This analysis counts referral events, not unique patients. Appointment Slot Issues indicate that no appointment slot was available at booking or search time. They do not directly prove clinical harm, deliberate capacity diversion or individual waiting outcomes.

RTT and diagnostic waiting-time indicators are used as downstream context only. They should not be interpreted as directly caused by e-RS appointment-slot pressure without patient-level linkage or causal modelling.

## License and Data Use

The code in this repository is released under the MIT License. Data belongs to the original public data providers. This repository uses publicly available NHS and ONS data sources for educational and portfolio purposes.
