# Reproducibility Guide

## 1. Clone the Repository

```bash
git clone https://github.com/pradeepthi1502-spec/nhs-ers-booking-gap-analysis.git
cd nhs-ers-booking-gap-analysis
```

## 2. Install Dependencies

```bash
pip install -r requirements.txt
```

## 3. Data Setup

Raw NHS files are not stored in the repository. Download source files using the links in:

```text
docs/data_sources.md
```

Place any raw files in:

```text
data/raw/
```

Processed files should be stored in:

```text
data/processed/
```

## 4. Run Python Scripts

Run the main e-RS processing script:

```bash
python src/build_ers_tableau_fact.py
```

Run supporting scripts if required:

```bash
python src/clean_rtt_monthly.py
python src/clean_dm01_diagnostics.py
python src/clean_cwt_cancer_waiting_times.py
python src/create_date_dimension_and_validate.py
python src/build_rtt_dumbbell_comparison.py
```

## 5. Open Tableau Workbook

Open the Tableau workbook from:

```text
tableau/workbook.twbx
```

Refresh the data source if required and point Tableau to the processed dataset in:

```text
data/processed/
```

## 6. Export Dashboard Screenshots

Save final dashboard screenshots in:

```text
tableau/screenshots/
```

Recommended screenshot names:

```text
dashboard_1_overview.png
story_page_1_demand_gap.png
story_page_2_concentration.png
story_page_3_intervention.png
```

## 7. Expected Outputs

Expected processed outputs may include:

```text
eRS_Tableau_Fact_Final.csv
eRS_region_summary.csv
eRS_specialty_bottlenecks.csv
eRS_archetype_summary.csv
rtt_monthly_clean.csv
dm01_diagnostics_clean.csv
cwt_cancer_waiting_times_clean.csv
```
