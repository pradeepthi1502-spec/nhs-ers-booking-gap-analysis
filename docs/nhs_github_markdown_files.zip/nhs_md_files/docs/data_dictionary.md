# Data Dictionary

This data dictionary describes the main fields used in the Tableau-ready dataset.

## Core Date Fields

| Field | Description |
|---|---|
| Week | Original reporting week or week range from source data |
| Week Ending Date | Cleaned date field representing the end of the reporting week |
| Month | Month derived from week ending date |
| Year Number | Calendar year derived from week ending date |
| Policy Period | Optional period grouping used for pre/post comparison |

## Geography Fields

| Field | Description |
|---|---|
| CCG Code | Clinical Commissioning Group or equivalent source geography code where available |
| CCG Name | Clinical Commissioning Group or equivalent source geography name where available |
| Sub ICB Code | Sub-Integrated Care Board code where available |
| Sub ICB Name | Sub-Integrated Care Board name where available |
| ICB Name | Integrated Care Board name |
| NHS England Region | NHS England region name |
| Region Latitude | Latitude used for regional Tableau mapping |
| Region Longitude | Longitude used for regional Tableau mapping |

## Service Fields

| Field | Description |
|---|---|
| Specialty | Clinical specialty or service area |
| Clinic Type | Referral clinic type from the e-RS data |
| Clinic Group | Grouped clinic type, such as urgent suspected cancer or routine / other clinic |

## Activity Fields

| Field | Description |
|---|---|
| Referrals | Number of referral events |
| Bookings | Number of booked appointment events |
| ASIs | Number of Appointment Slot Issue events |

## Engineered Metrics

| Field | Description |
|---|---|
| Booking Absorption Rate | Bookings divided by referrals |
| Demand-to-Booking Gap | Referrals minus bookings |
| Positive Demand Gap | Demand-to-booking gap where negative values are set to zero |
| ASI Rate per 10,000 Referrals | Appointment Slot Issues per 10,000 referrals |
| Routine ASI Rate per 10k | Routine Appointment Slot Issues per 10,000 routine referrals |
| 2WW ASI Rate per 10k | Urgent suspected cancer Appointment Slot Issues per 10,000 2WW referrals |
| Routine-to-2WW ASI Ratio | Comparison of routine no-slot pressure against 2WW no-slot pressure |
| Bottleneck Archetype | Operational pressure category based on absorption and ASI pressure |

## Notes

Field names may vary slightly depending on whether the file is a raw source file, interim file, processed file or Tableau export. The final processed dataset should use consistent, analysis-ready field names.
