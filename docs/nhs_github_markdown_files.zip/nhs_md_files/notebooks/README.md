# Notebooks

This folder contains step-by-step Jupyter notebooks used for data loading, cleaning, merging, metric engineering and validation.

## Notebook List

| Notebook | Purpose |
|---|---|
| 01_ers_tableau_fact_pipeline.ipynb | Builds the main e-RS Tableau fact table |
| 02_rtt_monthly_cleaning_pipeline.ipynb | Cleans RTT monthly data |
| 03_dm01_cleaning_pipeline.ipynb | Cleans diagnostic waiting-time data |
| 04_cwt_cleaning_pipeline.ipynb | Cleans cancer waiting-times data |
| 05_date_dimension_and_validation_checks.ipynb | Creates date dimensions and validation checks |
| 06_rtt_dumbbell_comparison_dataset.ipynb | Creates RTT comparison data for Tableau |

## Purpose

The notebooks are included to show the analytical thinking and step-by-step development process. Clean reusable scripts are stored separately in the `src` folder.
