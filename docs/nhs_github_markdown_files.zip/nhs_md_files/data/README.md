# Data Folder

This folder stores the datasets used in the project.

## Recommended Structure

```text
data/
├── raw/
├── interim/
└── processed/
```

## raw

Use this folder for original downloaded NHS and ONS source files. Raw files are not uploaded to GitHub if they are large or numerous.

## interim

Use this folder for temporary cleaned or merged files created during processing.

## processed

Use this folder for final analysis-ready datasets used by Tableau and GitHub reproducibility.

Recommended processed files:

```text
eRS_Tableau_Fact_with_Geography.csv
eRS_Tableau_Fact_Final.csv
eRS_region_summary.csv
eRS_specialty_bottlenecks.csv
eRS_archetype_summary.csv
```

## Data Use Note

Data belongs to the original public data providers. This project uses publicly available NHS and ONS data sources for educational and portfolio purposes.
