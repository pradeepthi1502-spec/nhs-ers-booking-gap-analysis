# Tableau Calculated Fields

This document lists the main Tableau calculated fields used in the project. Field names may need minor adjustment depending on the exact column names in the final Tableau dataset.

## Date Fields

### Month Clean

```tableau
DATETRUNC('month', [Week Ending Date])
```

### Year Number

```tableau
YEAR([Week Ending Date])
```

### Slope Year

```tableau
STR(YEAR([Week Ending Date]))
```

## Core Volume Fields

### Total ASIs

```tableau
SUM([ASIs])
```

### Total Referrals

```tableau
SUM([Referrals])
```

### Total Bookings

```tableau
SUM([Bookings])
```

## Core Metrics

### ASI Rate per 10,000 Referrals

```tableau
IF SUM([Referrals]) = 0 THEN NULL
ELSE SUM([ASIs]) / SUM([Referrals]) * 10000
END
```

### Booking Conversion Rate

```tableau
IF SUM([Referrals]) = 0 THEN NULL
ELSE SUM([Bookings]) / SUM([Referrals])
END
```

### Referral-Booking Gap

```tableau
SUM([Referrals]) - SUM([Bookings])
```

### Positive Referral-Booking Gap

```tableau
IF SUM([Referrals]) - SUM([Bookings]) > 0 THEN
    SUM([Referrals]) - SUM([Bookings])
ELSE 0
END
```

## Routine Metrics

### Routine ASIs

```tableau
SUM(
IF [Clinic Group] = 'Other Clinic / Routine' THEN [ASIs]
ELSE 0
END
)
```

### Routine Referrals

```tableau
SUM(
IF [Clinic Group] = 'Other Clinic / Routine' THEN [Referrals]
ELSE 0
END
)
```

### Routine Bookings

```tableau
SUM(
IF [Clinic Group] = 'Other Clinic / Routine' THEN [Bookings]
ELSE 0
END
)
```

### Routine ASI Rate per 10k

```tableau
IF [Routine Referrals] = 0 THEN NULL
ELSE [Routine ASIs] / [Routine Referrals] * 10000
END
```

### Routine Booking Conversion Rate

```tableau
IF [Routine Referrals] = 0 THEN NULL
ELSE [Routine Bookings] / [Routine Referrals]
END
```

### Routine Referral-Booking Gap

```tableau
[Routine Referrals] - [Routine Bookings]
```

## 2WW / Urgent Suspected Cancer Metrics

### 2WW ASIs

```tableau
SUM(
IF [Clinic Group] = '2WW / Urgent Suspected Cancer' THEN [ASIs]
ELSE 0
END
)
```

### 2WW Referrals

```tableau
SUM(
IF [Clinic Group] = '2WW / Urgent Suspected Cancer' THEN [Referrals]
ELSE 0
END
)
```

### 2WW Bookings

```tableau
SUM(
IF [Clinic Group] = '2WW / Urgent Suspected Cancer' THEN [Bookings]
ELSE 0
END
)
```

### 2WW ASI Rate per 10k

```tableau
IF [2WW Referrals] = 0 THEN NULL
ELSE [2WW ASIs] / [2WW Referrals] * 10000
END
```

### 2WW Booking Conversion Rate

```tableau
IF [2WW Referrals] = 0 THEN NULL
ELSE [2WW Bookings] / [2WW Referrals]
END
```

## Comparative Metrics

### Routine-to-2WW ASI Ratio

```tableau
IF [2WW ASI Rate per 10k] = 0 THEN NULL
ELSE [Routine ASI Rate per 10k] / [2WW ASI Rate per 10k]
END
```

### ASI Pressure Gap

```tableau
[Routine ASI Rate per 10k] - [2WW ASI Rate per 10k]
```

### Booking Conversion Gap

```tableau
[Routine Booking Conversion Rate] - [2WW Booking Conversion Rate]
```

## Geography Fields

### Region Latitude Clean

```tableau
FLOAT([Region Latitude])
```

### Region Longitude Clean

```tableau
FLOAT([Region Longitude])
```

## Bottleneck Classification

### ICB Pressure Group

```tableau
IF [Routine ASI Rate per 10k] >= 2400
AND [Routine Booking Conversion Rate] < 0.31 THEN
    'Booking bottlenecks'
ELSEIF [Routine ASI Rate per 10k] >= 2400
AND [Routine Booking Conversion Rate] >= 0.31 THEN
    'High pressure, still converting'
ELSEIF [Routine ASI Rate per 10k] < 2400
AND [Routine Booking Conversion Rate] < 0.31 THEN
    'Low conversion watchlist'
ELSE
    'Lower pressure, coping better'
END
```

## Baseline Fields

### Fixed Pre-Pandemic Routine Baseline

```tableau
{ FIXED : AVG(
    IF [Week Ending Date] >= #2019-10-01#
    AND [Week Ending Date] < #2020-03-01#
    THEN [Routine ASI Rate per 10k]
    END
) }
```

### Excess Routine ASIs

```tableau
IF [Routine ASIs] > [Expected Routine ASIs at Baseline] THEN
    [Routine ASIs] - [Expected Routine ASIs at Baseline]
ELSE 0
END
```

## Notes

- If Tableau already recognises `Week Ending Date` as a date, do not use `DATEPARSE()`.
- If a year filter appears as a slider, convert the year field to discrete or use `Slope Year` as a string.
- Tooltip fields should be inserted using Tableau's `Insert` button rather than typed manually.
