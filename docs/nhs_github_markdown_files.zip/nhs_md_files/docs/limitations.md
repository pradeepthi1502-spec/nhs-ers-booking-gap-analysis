# Limitations

## 1. Referral Events, Not Unique Patients

This analysis counts referral events rather than unique patients. A single patient may appear more than once if they have multiple referral events.

## 2. Appointment Slot Issues Are an Access-Pressure Signal

Appointment Slot Issues indicate that no appointment slot was available at booking or search time. They should be interpreted as an upstream access-pressure signal, not as direct evidence of patient harm.

## 3. No Direct Causal Claim

The analysis does not prove that e-RS Appointment Slot Issues caused RTT deterioration, diagnostic waits or individual patient delays. RTT and diagnostic waiting-time measures are used only as wider NHS access context.

## 4. e-RS Does Not Capture Every Referral Route

The e-Referral Service data captures activity within e-RS. Some referral pathways, providers or services may use other booking routes or local processes.

## 5. Geography Matching May Not Be Perfect

Geography enrichment depends on consistent Sub-ICB, CCG or organisation codes. Some records may not match cleanly due to boundary changes, code changes or missing values.

## 6. Partial Year Effects

Some year-level comparisons may be affected by partial years, especially 2019 and 2025 depending on data extract coverage. These periods should be interpreted carefully.

## 7. Operational Interpretation Requires Local Context

The bottleneck archetypes help prioritise areas for investigation, but they should not replace local operational knowledge. A high-pressure classification should be treated as a signal for review, not as a final diagnosis.

## 8. Dashboard-Level Aggregation

Aggregated charts can hide variation within providers, specialties or local services. Where possible, operational decisions should use more granular data alongside this analysis.

## Recommended Caveat

This analysis counts referral events, not unique patients. Appointment Slot Issues show where no appointment slot was available at booking or search time. They do not directly prove clinical harm, deliberate capacity diversion or individual waiting outcomes.
