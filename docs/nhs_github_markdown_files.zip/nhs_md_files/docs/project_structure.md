# Project Structure

```text
nhs-ers-booking-gap-analysis/
│
├── README.md
├── requirements.txt
├── .gitignore
├── LICENSE
│
├── data/
│   ├── raw/
│   │   └── .gitkeep
│   ├── interim/
│   │   └── .gitkeep
│   └── processed/
│       ├── eRS_Tableau_Fact_with_Geography.csv
│       ├── eRS_Tableau_Fact_Final.csv
│       ├── eRS_region_summary.csv
│       ├── eRS_specialty_bottlenecks.csv
│       └── eRS_archetype_summary.csv
│
├── notebooks/
│   ├── 01_ers_tableau_fact_pipeline.ipynb
│   ├── 02_rtt_monthly_cleaning_pipeline.ipynb
│   ├── 03_dm01_cleaning_pipeline.ipynb
│   ├── 04_cwt_cleaning_pipeline.ipynb
│   ├── 05_date_dimension_and_validation_checks.ipynb
│   └── 06_rtt_dumbbell_comparison_dataset.ipynb
│
├── src/
│   ├── build_ers_tableau_fact.py
│   ├── clean_rtt_monthly.py
│   ├── clean_dm01_diagnostics.py
│   ├── clean_cwt_cancer_waiting_times.py
│   ├── create_date_dimension_and_validate.py
│   └── build_rtt_dumbbell_comparison.py
│
├── tableau/
│   ├── workbook.twbx
│   └── screenshots/
│       ├── dashboard_1_overview.png
│       ├── story_page_1_demand_gap.png
│       ├── story_page_2_concentration.png
│       └── story_page_3_intervention.png
│
└── docs/
    ├── data_sources.md
    ├── methodology.md
    ├── metrics_and_definitions.md
    ├── data_dictionary.md
    ├── dashboard_story.md
    ├── tableau_calculated_fields.md
    ├── limitations.md
    ├── reproducibility.md
    └── project_structure.md
```

## Folder Purpose

| Folder | Purpose |
|---|---|
| data/raw | Raw public source files, not uploaded to GitHub if large |
| data/interim | Temporary cleaned or merged files |
| data/processed | Final analysis-ready datasets used by Tableau |
| notebooks | Step-by-step exploratory and cleaning notebooks |
| src | Clean reusable Python scripts |
| tableau | Tableau workbook and screenshots |
| docs | Methodology, data sources, metrics, limitations and project documentation |

## Recommended Upload Order

1. Root files: `README.md`, `.gitignore`, `LICENSE`, `requirements.txt`
2. `data/processed` files
3. `notebooks` files
4. `src` files
5. `tableau/screenshots` and workbook
6. `docs` markdown files
